package com.createUser.logger;
 
public interface ILogger {
	public void debug(String msg);

	public void info(String msg);

	public void error(String msg);

}

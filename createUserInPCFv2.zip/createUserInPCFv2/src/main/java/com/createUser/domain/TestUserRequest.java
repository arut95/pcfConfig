package com.createUser.domain;

import java.util.Date;

public class TestUserRequest {	 
	public String firstname;
	public String lastname;
	public Long employeeid;
	public String employeeemailid;
	public String supervisoremailid;
	public String department;
	public String proglanguage;
	public String phonenumber;
	public String timezone;
	public String uniqueid;
	public String activationstatus;
	public String activationdate;
	public String creationdate;
	public String lastmodifieddate;
	public Integer numberofattempts;
	public String orgid;
	public String proficiencylevel;
	public String frameworks;
	public String linuxskill;
	public String fullstackcompleted;
	public String fullstackskills;
	public String userthoughtstraning;
	public String usercommentstraining;
}

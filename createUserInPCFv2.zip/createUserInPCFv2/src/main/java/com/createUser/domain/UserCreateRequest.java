package com.createUser.domain;

public class UserCreateRequest {
	public String employeeEmailId; 
	public String uniqueid;
}
